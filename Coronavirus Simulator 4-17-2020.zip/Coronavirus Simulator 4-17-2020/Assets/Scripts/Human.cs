﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Human : ScriptableObject
{
    public GameObject person;
    public bool infected,inFamily;
    public int coop,age,boredom;
    public string personalityType,healthCondition;
    private string[] personalities,conditions;
    private int decider;

    public Human()
    {
        Setup();
    }

    void Setup()
    {
        personalities = new string[] { "Introverted", "Extroverted" };   //helps decide if they stay in or go out and their walking paths
        conditions = new string[] { "None", "Diabetes", "None", "Cancer", "None", "Asthma", "None", "Bronchitis", "None", "None" };  //Makes an accurate 40% rate of people with diseases

        infected = false;   //everyone starts fine, first people infected will be decided in the world script
        inFamily = false; //this is actually decided in the house script
        coop = Random.Range(5, 20);
        age = Random.Range(10, 80);
        boredom = 1;    //Boredom increases with time, the rate depending on personality and other variables

        decider = Random.Range(0, 2);
        personalityType = personalities[decider];   //chooses a personality type from the personalities list

        decider = Random.Range(0, 9);
        healthCondition = conditions[decider];  //chooses a condition from the conditions list
    }

    // Start is called before the first frame update
    void Start()
    {
        Setup();
    }
}
