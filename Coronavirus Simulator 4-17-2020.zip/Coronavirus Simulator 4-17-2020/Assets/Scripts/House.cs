﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class House : MonoBehaviour
{
    public Human[] family;
    public World world;
    public bool facingRight;    //should help with spawning humans at each house
    private int decider;

    public void FillHouse()
    {
        for (int i = 0; i < family.Length; i++)
        {
            decider = Random.Range(0, world.population.Length);

            if (!world.population[decider].inFamily)    //Loops through the world population and adds people without families to the house
            {
                family[i] = world.population[decider];
                world.population[decider].inFamily = true;
                Debug.Log("" + i);
            }
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        family = new Human[5];  //max family limit of 5 people
    }
}
