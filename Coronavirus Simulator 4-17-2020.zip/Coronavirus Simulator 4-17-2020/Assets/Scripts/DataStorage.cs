﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DataStorage : MonoBehaviour
{
    public int healthCareCapacity, infected;
    public int population;
    public StartingOptions options;
    public GameObject storage;
    public GameObject collector;
    public GameObject EscToGoToMenu;
    public bool cooperation;

    public void TransferData()
    {
        population = options.population;    //transfers slider data to this script
        healthCareCapacity = options.healthCareCapacity;
        infected = options.infected;
        cooperation = options.cooperation;
    }

    // Update is called once per frame
    void Update()
    {
        DontDestroyOnLoad(EscToGoToMenu);
        DontDestroyOnLoad(collector);
        DontDestroyOnLoad(storage);  //carries the data over to the simulation scene
    }
}
