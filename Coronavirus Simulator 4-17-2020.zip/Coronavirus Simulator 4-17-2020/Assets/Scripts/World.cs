﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class World : MonoBehaviour
{
    public int currentPopulationLoaded;

    public GameObject person;
    public Human[] population;
    public GameObject[] objectPopulation;
    public House[] neighborhood;
    public DataStorage data;

    private void Start()
    {
        population = new Human[data.population];    //for storing scripts
        objectPopulation = new GameObject[data.population]; //for storing gameobjects


        for (int i = 0; i < objectPopulation.Length; i++)
        {
            objectPopulation[i] = Instantiate(person);  //adds a gameobject clone to the array
            population[i] = new Human();    //adds a script to the array
        }

        for (int i = 0; i < neighborhood.Length; i++)
        {
            neighborhood[i].FillHouse();    //fills each house on the map with a family
        }

        /*
        for(int i = 0; i < data.population; i++)
        {
            Debug.Log("" + population[i].coop);
        }
        */
    }

    // Start is called before the first frame update
    void Update()
    {

    }
}
